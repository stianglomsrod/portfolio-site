# DNB Context Brief

## Goal
Build a separate DNB-targeted portfolio variant for the role Software Engineer, AI-First Engineering, while preserving the original VG X portfolio.

## Positioning in one line
Stian is an AI-first builder / software engineering candidate with strong system understanding, practical fullstack delivery, documented agentic workflow discipline, and research-backed product framing.

## Non-negotiables
- Do not present Stian as a senior distributed systems/platform engineer.
- Do not present Stian as a pure UX designer.
- Do not present Stian as only a prompt user.
- Emphasize practical understanding of frontend, backend, APIs, database, auth, frameworks, CSS libraries, and deployment structure.
- Emphasize AI-assisted prototyping and AI-assisted development.
- Keep claims evidence-based and technically honest.
- No private/medical framing.
- Do not make the page look like official DNB material.

## Current objective for collaborators
Turn strategy into high-quality content and then into small, reviewable implementation chunks. Prioritize safety, clarity, and evidence over hype.

## Delivery style
Concrete, human, technically curious, honest, useful for DNB AI Tech.