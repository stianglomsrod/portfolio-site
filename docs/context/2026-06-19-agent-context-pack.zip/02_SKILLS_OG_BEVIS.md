# Skills and Evidence Matrix

## Core skills to communicate

### 1) AI-first engineering workflow
- Skill: Uses AI agents as engineering partners with context, constraints, review, correction, QA, and handoff.
- Evidence:
  - docs/dnb/DNB_WORKFLOW_DNA.md
  - docs/dnb/DNB_AGENT_HANDOFF_PROTOCOL.md
  - docs/dnb/DNB_QA_CHECKLIST.md
  - docs/dnb/DNB_IMPLEMENTATION_LOG.md

### 2) Practical fullstack system understanding
- Skill: Connects frontend, backend, auth, data, and product flow in real builds.
- Evidence:
  - docs/dnb/DNB_CONTENT_OUTLINE.md
  - docs/dnb/DNB_SECTION_COPY_V1.md
  - Klar references documented in DNB content files

### 3) Product decision quality under constraints
- Skill: Converts unclear needs into buildable and testable decisions.
- Evidence:
  - Participatory Design and Design Science framing in docs/dnb/DNB_CONTENT_OUTLINE.md
  - Section copy in docs/dnb/DNB_SECTION_COPY_V1.md

### 4) Learning velocity and sustained output
- Skill: Moves from new knowledge to working prototypes, docs, workflows, and systems.
- Evidence:
  - docs/dnb/DNB_POSITIONING.md
  - docs/dnb/DNB_IMPLEMENTATION_LOG.md
  - Structured documentation set under docs/dnb/

## Klar-specific technical evidence (must be kept honest)
- Fullstack PWA
- React/Next.js
- Supabase/PostgreSQL/Auth/RBAC
- Teacher/student role structure
- Smart Import as explicit AI product decision
- Human-in-the-loop preview before publishing
- Safety/privacy constraints
- IMPORTANT: Do not overclaim production scale or senior platform depth.

## Claims to avoid
- No claim of completed student user-testing if not documented.
- No senior distributed systems claim.
- No established lower-level expertise claim.
- No pure UX framing.
- No prompt-user-only framing.
- No unsupported claims.