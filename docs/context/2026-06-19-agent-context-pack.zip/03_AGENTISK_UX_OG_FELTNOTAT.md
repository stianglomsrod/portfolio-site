# Agentic UX and Real-World Field Note

## Product principle
A beautiful interface is not enough. If a solution breaks down in real workflows, it fails the job.

## User direction (high priority)
The user is highly motivated by agentic + authentic UX design and development: tools must survive real daily operations, not just demos.

## Field note: Halden taxi voice interaction (2026-06-17)
- Voice system misunderstood input twice.
- Destination input "2E" was interpreted and accepted as "2A".
- The interaction exposed a gap between tech expectations and operational reliability.

## Why this matters for AI-first engineering
- Reliability under noise/ambiguity matters more than polished first impression.
- Human confirmation loops and correction UX are mandatory when errors have operational impact.
- Evaluate systems against real usage context, not only feature completion.

## Design and engineering implications
- Add explicit confirmation checkpoints where errors are costly.
- Prefer recoverable flows over brittle one-shot automation.
- Measure success in workflow outcomes, not just UI delight or model output quality.
- Treat edge-case behavior as first-class product work.

## Note for future agent sessions
The user invited deeper expansion on this field note and sees large opportunity space here. Ask for concrete follow-up examples when refining product concepts.