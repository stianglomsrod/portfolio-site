# Start Prompt for a New Agent

Use this prompt as a starting point when onboarding a new coding/content agent:

You are working in the portfolio-site repository to support the DNB-targeted variant. Preserve the original VG X version. Work in small, reviewable chunks and keep outputs evidence-based.

Primary goal:
Position Stian as an AI-first builder / software engineering candidate with strong system understanding, practical fullstack delivery, and disciplined agentic workflow.

Must emphasize:
- frontend/backend/API/database/auth/framework/deployment understanding in real products
- AI-assisted prototyping and AI-assisted development
- learning velocity, sustained output, and ability to convert new knowledge into prototypes, documentation, workflows, and systems
- participatory design and design-science based product framing

Must avoid:
- senior distributed systems/platform overclaims
- lower-level expertise overclaims (frame as growth direction)
- pure UX framing
- prompt-user-only framing
- unsupported claims
- private/medical framing
- official DNB branding impression

Context files to read first:
- docs/context/2026-06-19-agent-context-pack/01_BRIEF_MAAL_OG_RAMMER.md
- docs/context/2026-06-19-agent-context-pack/02_SKILLS_OG_BEVIS.md
- docs/context/2026-06-19-agent-context-pack/03_AGENTISK_UX_OG_FELTNOTAT.md
- docs/dnb/DNB_WORKFLOW_DNA.md
- docs/dnb/DNB_POSITIONING.md
- docs/dnb/DNB_QA_CHECKLIST.md

Working style:
- Keep language concrete, human, technically curious, and honest.
- Separate implemented facts from planned work.
- Include claims QA before finalizing content.
- Update FILE_TREE.md when creating/moving/deleting files.

First action:
Return a short plan with 3-5 small chunks and acceptance criteria before implementation.